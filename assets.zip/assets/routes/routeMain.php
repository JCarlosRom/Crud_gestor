<?php  
	
	//session_start();

	require('../clases/Main.php');
	$Main= new Main();
//	$Main = new mysql();



	$action = $_POST['action'];
	
	
	if(isset($_POST['info']))
		$info = $_POST['info'];

	switch ($action) {
		case 'enviar':
		$nombre=$info["nombre"];
		$correo=$info["correo"];
		$telefono=$info["telefono"];
		$asunto="Contacto";
		$mensaje=$info["mensaje"];

		$msg = '<!DOCTYPE html>
				<html lang="en">
				<head>
				    <meta charset="utf-8">
				    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

				</head>
				<body>';
		$msg .= 	"<div class='col-md-12'>
	        
				        <h3>Tienes una nueva solicitud de contacto!</h3>

				        <p><strong>Nombre:</strong> {$nombre}</p>
				        <p><strong>Email:</strong> {$correo}</p>
				        <p><strong>Telefono:</strong> {$telefono}</p>
				        <p><strong>Mensaje:</strong> </p>
				        <p>{$mensaje}</p>
				    </div>
			    </body>
				</html>";
		echo json_encode($Main->sendMailLocal($msg,$asunto));
			break;
	}
	
?>